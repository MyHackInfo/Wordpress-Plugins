<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       narsi.com
 * @since      1.0.0
 *
 * @package    Visitorcounter
 * @subpackage Visitorcounter/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Visitorcounter
 * @subpackage Visitorcounter/admin
 * @author     narsi <narsi@prpwebs.in>
 */
class Visitorcounter_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Visitorcounter_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Visitorcounter_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/visitorcounter-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Visitorcounter_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Visitorcounter_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/visitorcounter-admin.js', array( 'jquery' ), $this->version, false );

	}

	public function visitor_counters(){
		add_menu_page("Visitor Counter","Visitor Counter","manage_options","visitor-counter","","dashicons-chart-pie",8);
		add_submenu_page("visitor-counter","Visitor Counter Option","Visitor Counter Option","manage_options","visitor-counter-option",array($this,"getipaddr"));
	}

	public function getipaddr(){
		include_once 'partials/visitorcounter-admin-display.php';
	}


	// visitor counter function and update value on database
	public function showvisitor(){
			global $wpdb;
			
			$visitor_num = $wpdb->get_results("SELECT visitor_number FROM visitor_counter", ARRAY_A);
			
			if(!empty($_SERVER['HTTP_CLIENT_IP'])){

				// check ip from share internet
				$ip = $_SERVER['HTTP_CLIENT_IP'];
			} elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
				{
					//to check ip is pass from proxy
					$ip= $_SERVER['HTTP_X_FORWARDED_FOR'];
				}else{
					$ip = $_SERVER['REMOTE_ADDR'];
				}

				
				$part = explode("::", $ip);
				
				if(empty($visitor_num)){
					$data = array(
						'pageName'=>'Home Page',
						'visitor_number'=>$part[1]
						);
					$wpdb->insert('visitor_counter',$data);

				}else{
					$data = array(
						'pageName'=>'Home Page',
						'visitor_number'=>$visitor_num[0]['visitor_number']+1
					);
					
					$wpdb->update('visitor_counter',$data,array('visitor_number'=>$visitor_num[0]['visitor_number']));
				}	
				


		}
	
	// shortcode for display visito number
	public function visitor_count_img($atts, $content = ""){
		include_once 'partials/visitor-counter-value.php';

	}

}
