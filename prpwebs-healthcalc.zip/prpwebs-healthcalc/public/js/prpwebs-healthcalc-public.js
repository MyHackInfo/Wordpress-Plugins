(function( jQuery ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * jQuery function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * jQuery(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * jQuery( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	 jQuery(document).ready(function(){
	// validate contact form on keyup and submit
	jQuery("#calculator").validate({
		//set the rules for the field names
		rules: {
			member_age: {
				required: true,
				maxlength: 3,
				min: 13
			},
			member_weight: {
				required: true,
				minlength: 2,
				min: 50
			},
			member_height_in: {
				required: true
			},
			member_waist_in: {
				required: true
			},
			member_score_sleep: {
				required: true
			},
			member_score_exercise: {
				required: true
			},
			member_score_smoking: {
				required: true
			},
			member_score_alcohol: {
				required: true
			},
			member_score_diet: {
				required: true
			},
			member_score_nutrition: {
				required: true
			},
			member_score_emotional: {
				required: true
			},
		},
		//set messages to appear inline
		messages: {
			member_age: {
				required: "<strong>Age</strong> is required",
				min: "<strong>Age</strong> must be 13 or older",
				maxlength: "<strong>Age</strong> must be 3 digits or less"
			},
			member_weight: {
				required: "<strong>Weight</strong> is required",
				minlength: "<strong>Weight</strong>: Please enter a weight greater than 50 lbs.",
				min: "<strong>Weight</strong>: Please enter a weight greater than 50 lbs."
			},
			member_height_in: {
				required: "<strong>Height in inches</strong> is required.",
				max: "Please enter a value less than 12"
			},
			member_waist_in: "<strong>Waist</strong> size is required",
			member_score_sleep: "<strong>Sleep</strong> is required",
			member_score_exercise: "<strong>Exercise</strong> is required",
			member_score_smoking: "<strong>Smoking</strong> is required",
			member_score_alcohol: "<strong>Alcohol</strong> is required",
			member_score_diet: "<strong>Diet</strong> is required",
			member_score_nutrition: "<strong>Nutrition</strong> is required",
			member_score_emotional: "<strong>Emotional Well-being</strong> is required",
		},
		errorContainer: "#messageBox",
		errorLabelContainer: "#messageBox ul",
		wrapper: "li",
		errorElement: "span",
	});
});


})( jQuery );



function healthcalc (form) {
	
	/* Set default values */
	var age = 0;
	var weight = 0;
	var heightInches = 0;
	var waistInches = 0;
	var sleep = 0;
	var exercise = 0;
	var smoking = 0;
	var alcohol = 0;
	var diet = 0;
	var nutrition = 0;
	var emotional = 0;
	
	
	/* Check form values and set variable to form values */
	
	/* Age */
	var age = jQuery("#member_age").val();
	
	
	/* Weight */
	var weight = jQuery("#member_weight").val();
	
	
	/* Height */
	var heightInches = jQuery("#member_height_in").val();
	
	
	/* Healthy Weight Minimum */
	var healthyWeightMin = Math.round( ( 18.5 / 703 ) * ( heightInches * heightInches ) );
	
	
	/* Healthy Weight Maximum */
	var healthyWeightMax = Math.round( ( 24.9 / 703 ) * ( heightInches * heightInches ) );
	
	
	/* Waist */
	var waistInches = jQuery("#member_waist_in").val();
	
	
	/* Waist Points */
	var waistPoints = Math.round( ( 11 - ( Math.abs( ( waistInches / heightInches ) - .45 ) * 60 ) ) * 100 ) / 100;
	
	
	/* BMI */
	var bmi = ( weight / ( heightInches * heightInches ) ) * 703;
	
	
	/* BMI Points */
	var bmiPoints = 11 - Math.abs( bmi - 21.7 );
	
	
	/* Sleep */
	if ( ( jQuery(".member_score_sleep:checked").val() - 0 ) ) {
	
		var sleep = jQuery(".member_score_sleep:checked").val() - 0;
		
	}
	
	
	/* Exercise */
	if ( ( jQuery(".member_score_exercise:checked").val() - 0 ) ) {
	
		var exercise = jQuery(".member_score_exercise:checked").val() - 0;
		
	}
	
	
	/* Smoking */
	if ( ( jQuery(".member_score_smoking:checked").val() - 0 ) ) {
	
		var smoking = jQuery(".member_score_smoking:checked").val() - 0;
		
	}
	
	
	/* Alcohol */
	if ( ( jQuery(".member_score_alcohol:checked").val() - 0 ) ) {
	
		var alcohol = jQuery(".member_score_alcohol:checked").val() - 0;
		
	}
	
	
	/* Diet */
	if ( ( jQuery(".member_score_diet:checked").val() - 0 ) > 0 ) {
	
		var diet = jQuery(".member_score_diet:checked").val() - 0;
		
	}
	
	
	/* Nutrition */
	if ( ( jQuery(".member_score_nutrition:checked").val() - 0 ) ) {
	
		var nutrition = jQuery(".member_score_nutrition:checked").val() - 0;
		
	}
	
	
	/* Emotional */
	if ( ( jQuery(".member_score_emotional:checked").val() - 0 ) ) {
	
		var emotional = jQuery(".member_score_emotional:checked").val() - 0;
		
	}
	
	
	/* Total Score */
	var scoreTotal = Math.round((sleep + exercise + alcohol + smoking + diet + nutrition + emotional + bmiPoints + waistPoints)*10)/10;
	
	
	/* Health Risk */
	var scoreRisk = Math.round((100 - scoreTotal)*10)/10;
	

	/* Send values to modal if all questions have been answered */
	if (weight > 0 && heightInches > 0 && waistInches > 0 && sleep && exercise && alcohol && smoking != null && diet && nutrition && emotional) {
	
		jQuery("#js-modal-health-score").html(scoreTotal);
		jQuery("#js-modal-health-risk").html('According to your health score, you have a ' + scoreRisk + '% risk of developing a lifestyle related disease such as heart disease, cancer, or diabetes.');
		
	} else {
	
		jQuery("#js-modal-health-score").html('???');
		jQuery("#js-modal-health-risk").html('Please fill out the form completely to see your health score.');
		
	}
	
	
	/* Output all values to .diagnostic-panel. Remove for production */
	jQuery("#js-member-age").html(age);
	jQuery("#js-member-weight").html(weight);
	jQuery("#js-member-weight-min").html(healthyWeightMin);
	jQuery("#js-member-weight-max").html(healthyWeightMax);
	jQuery("#js-member-height-in").html(heightInches);
	jQuery("#js-member-waist-in").html(waistInches);
	jQuery("#js-member-waist-points").html(waistPoints);
	jQuery("#js-member-bmi").html(bmi);
	jQuery("#js-member-bmi-points").html(bmiPoints);
	jQuery("#js-member-sleep").html(sleep);
	jQuery("#js-member-exercise").html(exercise);
	jQuery("#js-member-smoking").html(smoking);
	jQuery("#js-member-alcohol").html(alcohol);
	jQuery("#js-member-diet").html(diet);
	jQuery("#js-member-nutrition").html(nutrition);
	jQuery("#js-member-emotional").html(emotional);
	jQuery("#js-member-score-total").html(scoreTotal);
	jQuery("#js-member-score-total-input").val(scoreTotal);
	jQuery("#js-member-score-risk").html(scoreRisk);

}
