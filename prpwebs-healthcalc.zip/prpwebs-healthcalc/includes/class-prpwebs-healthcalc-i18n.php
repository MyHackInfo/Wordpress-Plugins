<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://www.prpwebs.com/
 * @since      1.0.0
 *
 * @package    Prpwebs_Healthcalc
 * @subpackage Prpwebs_Healthcalc/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Prpwebs_Healthcalc
 * @subpackage Prpwebs_Healthcalc/includes
 * @author     narsi <narsi@prpwebs.in>
 */
class Prpwebs_Healthcalc_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'prpwebs-healthcalc',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
