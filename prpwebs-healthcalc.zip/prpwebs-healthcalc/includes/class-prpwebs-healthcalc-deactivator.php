<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://www.prpwebs.com/
 * @since      1.0.0
 *
 * @package    Prpwebs_Healthcalc
 * @subpackage Prpwebs_Healthcalc/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Prpwebs_Healthcalc
 * @subpackage Prpwebs_Healthcalc/includes
 * @author     narsi <narsi@prpwebs.in>
 */
class Prpwebs_Healthcalc_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
