<?php

// =============================================================================
// FUNCTIONS/GLOBAL/PLUGINS/GRAVITY-FORMS.PHP
// -----------------------------------------------------------------------------
// Plugin setup for theme compatibility.
// =============================================================================

// =============================================================================
// TABLE OF CONTENTS
// -----------------------------------------------------------------------------
//   01. Styles
// =============================================================================

// Styles
// =============================================================================

function x_gravity_forms_enqueue_styles() {

  // Stack Data
  // ----------

  $stack  = x_get_stack();
  $design = x_get_option( 'x_integrity_design' );

  if ( $stack == 'integrity' && $design == 'light' ) {
    $ext = '-light';
  } elseif ( $stack == 'integrity' && $design == 'dark' ) {
    $ext = '-dark';
  } else {
    $ext = '';
  }

  wp_enqueue_style( 'x-gravity-forms', X_TEMPLATE_URL . '/framework/dist/css/site/gravity_forms/' . $stack . $ext . '.css', array( 'gforms_reset_css', 'gforms_formsmain_css', 'gforms_ready_class_css', 'gforms_browsers_css' ), X_ASSET_REV, 'all' );

}


add_action('x_enqueue_styles', 'x_gravity_forms_checker', -1);

function x_gravity_forms_checker () {

    if ( is_plugin_active('gravityforms/gravityforms.php') ) {
      
      //Enqueue it globally but only when element or shortcode is present
      //The hook gform_enqueue_scripts is late binded, it appears after other enqueue or in the footer if it's called within the content.
      $checker = CS()->component('Shortcode_Finder');
      $shortcode = 'gravityform';

      global $post;

      if ( is_a( $post, 'WP_POST' ) ) { 

          //check content of the current post
          $checker->process_content($shortcode, $post->ID);//shortcode
          $checker->process_content($shortcode, $post->ID, false); //for classic gravity form element

      } 

      //check header and footer
      $header_assignment = CS()->component('Header_Assignments')->locate_assignment();
      $checker->process_content( $shortcode, $header_assignment, false );

      $footer_assignment = CS()->component('Footer_Assignments')->locate_assignment();
      $checker->process_content( $shortcode, $footer_assignment, false );

      //if present, then enqueue it
      if ( $checker->has($shortcode) ) x_gravity_forms_enqueue_styles();

  }

}
