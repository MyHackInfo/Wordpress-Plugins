<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://www.prpwebs.com/
 * @since      1.0.0
 *
 * @package    Prp_bestandvs
 * @subpackage Prp_bestandvs/public/partials
 */

global $wpdb;

$price_data = $wpdb->get_results("SELECT * FROM prp_price_plan", ARRAY_A);

$imgurl = $price_data[0]["imageUrl"];
$price = $price_data[0]["price"];
$buttonText = $price_data[0]["buttonText"];
$buttonUrl = $price_data[0]["buttonUrl"];

?>
<style type="text/css">
.bestandvs-show-main{
 	display: flex;
    padding: 10px;
    border: 1px solid #e2e2e4;
    background-color: #f8f9fb;
    justify-content: center;
    max-width:100%!important;
    border-radius: 5px;
 }
 .bestandvs-show-col{
 	width: 100%;
 	padding:5px;
 	display: grid;
    justify-content: center;
    align-content: center;
    text-align: center;
 }
.bestandvs-show-col-one img{width: 200px;
    height: 80px;}

 .bestandvs-col3-txt a{background-color: #18bc77;
    color: #fff;
    text-decoration: blink;
    padding: 10px 15px;
    border-radius: 5px;
 }
.bestandvs-show-main p{
	margin-bottom: 5px;
}
.bestandvs-col-txt2 .all-plans{border: 1px solid #74797c;
    padding: 1px 6px;
    border-radius: 5px;} 
.bestandvs-col-txt1{
	font-size: 25px;
}

@media(max-width: 980px){
	.bestandvs-col-txt1{
		font-size: 21px;
	}
	.bestandvs-col-txt2{
		font-size: 19px;
	}
	.bestandvs-show-col{
		padding:2px;
	}
	.bestandvs-show-main{
		padding:2px;
	}
}

@media(max-width: 790px){
	.bestandvs-show-col-two{
		padding:30px 10px;
	}
	.bestandvs-show-main{display: table;
    padding: 40px;}
}

@media(max-width: 480px){
	.bestandvs-col-txt1{
		font-size: 20px;
	}
	.bestandvs-col-txt2{
		font-size: 18px;
	}
	.bestandvs-show-main{
		padding:20px;
	}
}

</style>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="bestandvs-show-main">
	<div class="bestandvs-show-col-one bestandvs-show-col">
		<img src="<?php echo $imgurl ?>">
		<p>Review</p>
	</div>
	
	<div class="bestandvs-show-col-two bestandvs-show-col">
		<p class="bestandvs-col-txt1"> Starts from <span><b>$ <?php echo $price ?></b></span> per month</p>
		<p class="bestandvs-col-txt2">Free plan available <span class="all-plans"> All Plans</span> </p>
	</div>

	<div class="bestandvs-show-col-three bestandvs-show-col">
		<p class="bestandvs-col3-txt"><a href="<?php echo $buttonUrl ?>"><?php echo $buttonText ?></a></p>
	</div>

</div>