<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://www.prpwebs.com/
 * @since      1.0.0
 *
 * @package    Prp_bestandvs
 * @subpackage Prp_bestandvs/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Prp_bestandvs
 * @subpackage Prp_bestandvs/includes
 * @author     cgpandey <cgpandey@yahoo.com>
 */
class Prp_bestandvs_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

		global $wpdb;
		
		$table_name = 'prp_price_plan';
		// remove table form database of visitor counter value
		$sql = "DROP TABLE IF EXISTS $table_name";
		$wpdb->query($sql);
		delete_option("my_plugin_db_version");

	}

}
