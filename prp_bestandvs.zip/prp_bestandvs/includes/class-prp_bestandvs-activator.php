<?php

/**
 * Fired during plugin activation
 *
 * @link       https://www.prpwebs.com/
 * @since      1.0.0
 *
 * @package    Prp_bestandvs
 * @subpackage Prp_bestandvs/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Prp_bestandvs
 * @subpackage Prp_bestandvs/includes
 * @author     cgpandey <cgpandey@yahoo.com>
 */
class Prp_bestandvs_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

		global $wpdb;
		// table for design form 
		$table_name = 'prp_price_plan';
		if ( ! empty( $wpdb->charset ) ) {
		$charset_collate = "DEFAULT CHARACTER SET $wpdb->charset";
		}
		if ( ! empty( $wpdb->collate ) ) {
		$charset_collate .= " COLLATE $wpdb->collate";
		}
		// Add one library admin function for next function
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

		// Data table
		$sql = "CREATE TABLE $table_name (
		  
		  id mediumint(9) NOT NULL AUTO_INCREMENT,
		  imageUrl varchar(200) NOT NULL,
		  price int(200) NOT NULL,
		  buttonText varchar(200) NOT NULL,
		  buttonUrl varchar(200) NOT NULL,
		  PRIMARY KEY  (id)
		  
		  ) $charset_collate;";
		dbDelta( $sql );

	}

}
