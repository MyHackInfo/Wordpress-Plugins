<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://www.prpwebs.com/
 * @since      1.0.0
 *
 * @package    Prp_bestandvs
 * @subpackage Prp_bestandvs/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Prp_bestandvs
 * @subpackage Prp_bestandvs/includes
 * @author     cgpandey <cgpandey@yahoo.com>
 */
class Prp_bestandvs_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'prp_bestandvs',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
