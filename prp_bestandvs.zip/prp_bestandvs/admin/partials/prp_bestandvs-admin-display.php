<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://www.prpwebs.com/
 * @since      1.0.0
 *
 * @package    Prp_bestandvs
 * @subpackage Prp_bestandvs/admin/partials
 */
global $wpdb;

if(isset($_POST['Submit'])){

	$imgUrl = $_POST['imgUrl'];
	$price = $_POST['price'];
	$buttonText = $_POST['buttonText'];
	$buttonUrl = $_POST['buttonUrl'];
	$table_name = 'prp_price_plan';

	$data_inside = $wpdb->get_results("SELECT * FROM prp_price_plan", ARRAY_A);

	if(empty($data_inside)){
		$insert_data = $wpdb->insert($table_name, array('imageUrl' => $imgUrl, 
			'price' => $price,
			'buttonText' => $buttonText,
			'buttonUrl' => $buttonUrl,
		) ); 
		if($insert_data == true){
			echo "<h2>Submission Done</h2>";
		}else{
			echo "<h2>Submission Not Done</h2>";
		}

	}else{

		$update_data = $wpdb->update($table_name, array('imageUrl' => $imgUrl, 
			'price' => $price,
			'buttonText' => $buttonText,
			'buttonUrl' => $buttonUrl
		),array( 'ID' => 1 )); 

		if($update_data == true){
			echo "<h2>Update Done</h2>";
		}else{
			echo "<h2>Update Not Done</h2>";
		}

	}

}

?>

<style type="text/css">
	h2{
		color: green;
	}
</style>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<h1>Fill the design details.</h1>

<form method="post" id="form_submit">

<label>Image Url</label><br>
<input type="url" id="imgUrl" placeholder="Enter Image Url" name="imgUrl"><br><br>

<label>Price</label><br>
<input type="number" id="price" placeholder="$0.00" name="price"><br><br>

<label>Button text</label><br>
<input type="text" id="buttonText" placeholder="Enter Button Text" name="buttonText"><br><br>

<label>Button Url</label><br>
<input type="url" id="buttonUrl" placeholder="Enter Button Url" name="buttonUrl"><br><br>
<input type="submit" value="Submit" name="Submit">
</form>