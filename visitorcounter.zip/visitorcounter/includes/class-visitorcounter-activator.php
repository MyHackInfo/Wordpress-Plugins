<?php

/**
 * Fired during plugin activation
 *
 * @link       narsi.com
 * @since      1.0.0
 *
 * @package    Visitorcounter
 * @subpackage Visitorcounter/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Visitorcounter
 * @subpackage Visitorcounter/includes
 * @author     narsi <narsi@prpwebs.in>
 */
class Visitorcounter_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

		global $wpdb;
		// table for visitor counter value
		$table_name = 'visitor_counter';
		if ( ! empty( $wpdb->charset ) ) {
		$charset_collate = "DEFAULT CHARACTER SET $wpdb->charset";
		}
		if ( ! empty( $wpdb->collate ) ) {
		$charset_collate .= " COLLATE $wpdb->collate";
		}
		// Add one library admin function for next function
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

		// Data table
		$sql = "CREATE TABLE $table_name (
		  
		  pageName varchar(100) NOT NULL,
		  visitor_number varchar(100) NOT NULL
		  
		  ) $charset_collate;";
		dbDelta( $sql );


		// table for img style
		$table_name = 'visitor_counter_img';
		if ( ! empty( $wpdb->charset ) ) {
		$charset_collate = "DEFAULT CHARACTER SET $wpdb->charset";
		}
		if ( ! empty( $wpdb->collate ) ) {
		$charset_collate .= " COLLATE $wpdb->collate";
		}
		// Add one library admin function for next function
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

		// Data table
		$sql = "CREATE TABLE $table_name (
		  
		  imgName varchar(100) NOT NULL,
		  img_style varchar(100) NOT NULL
		  
		  ) $charset_collate;";
		dbDelta( $sql );



	}

}
