<?php

/**
 * Fired during plugin deactivation
 *
 * @link       narsi.com
 * @since      1.0.0
 *
 * @package    Visitorcounter
 * @subpackage Visitorcounter/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Visitorcounter
 * @subpackage Visitorcounter/includes
 * @author     narsi <narsi@prpwebs.in>
 */
class Visitorcounter_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

		global $wpdb;
		
		// remove table form database of visitor counter value
		$sql = "DROP TABLE IF EXISTS visitor_counter";
		$wpdb->query($sql);
		delete_option("my_plugin_db_version");

		// remove table form database of img style 
		$sql = "DROP TABLE IF EXISTS visitor_counter_img";
		$wpdb->query($sql);
		delete_option("my_plugin_db_version");


	}

}
