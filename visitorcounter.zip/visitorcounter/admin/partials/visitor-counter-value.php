<?php 

global $wpdb;
$visitor_count_value = $wpdb->get_results("SELECT visitor_number FROM visitor_counter",ARRAY_A);
echo $visitor_count_value[0]['visitor_number']; 
$img_style = $wpdb->get_results("SELECT img_style FROM visitor_counter_img", ARRAY_A);

$images_folder =$img_style[0]['img_style']; ?>

<table class="form-table">
	<tbody>
		<tr>
        <td>
            <img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/<?=$images_folder?>/<?=$visitor_count_value[0]['visitor_number']?>.gif">
            <img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/<?=$images_folder?>/1.gif">
            <img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/<?=$images_folder?>/2.gif">
            <img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/<?=$images_folder?>/<?=$visitor_count_value[0]['visitor_number']?>.gif">
            <img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/<?=$images_folder?>/4.gif">
            </td>
            </tr>
		<tr>
	</tbody>
</table>