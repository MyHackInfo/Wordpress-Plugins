<div class="plugins_text" style="float:left;">
	<h3 class="hndle">Image Counter</h3>
<form method="post" id="form_submit">      		  					
        <p><b>Choose one of the image counter styles below:</b></p>
	<table class="form-table">
		<tbody><tr>
                	<td>
                	<input type="radio" id="img1" name="visitor_counter_style" value="bbldotg">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/bbldotg/0.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/bbldotg/1.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/bbldotg/2.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/bbldotg/3.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/bbldotg/4.gif">
                	</td>
                </tr>
		<tr>
                	<td>
                	<input type="radio" id="img1" name="visitor_counter_style" value="calculator">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/calculator/0.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/calculator/1.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/calculator/2.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/calculator/3.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/calculator/4.gif">
                	</td>
                </tr>
			<tr>
                	<td>
                	<input type="radio" id="img1" name="visitor_counter_style" value="chevy">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/chevy/0.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/chevy/1.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/chevy/2.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/chevy/3.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/chevy/4.gif">
                	</td>
                </tr>
		<tr>
                	<td>
                	<input type="radio" id="img1" name="visitor_counter_style" value="cntdwn">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/cntdwn/0.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/cntdwn/1.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/cntdwn/2.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/cntdwn/3.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/cntdwn/4.gif">
                	</td>
                </tr>
		<tr>
                	<td>
                	<input type="radio" id="img1" name="visitor_counter_style" value="computer" checked="checked">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/computer/0.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/computer/1.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/computer/2.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/computer/3.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/computer/4.gif">
                	</td>
                </tr>
		<tr>
                	<td>
                	<input type="radio" id="img1" name="visitor_counter_style" value="glass">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/glass/0.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/glass/1.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/glass/2.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/glass/3.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/glass/4.gif">
                	</td>
                </tr>
		<tr>
                	<td>
                	<input type="radio" id="img1" name="visitor_counter_style" value="led">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/led/0.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/led/1.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/led/2.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/led/3.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/led/4.gif">
                	</td>
                </tr>
		<tr>
                	<td>
                	<input type="radio" id="img1" name="visitor_counter_style" value="links">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/links/0.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/links/1.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/links/2.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/links/3.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/links/4.gif">
                	</td>
                </tr>
		<tr>
                	<td>
                	<input type="radio" id="img1" name="visitor_counter_style" value="marsil">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/marsil/0.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/marsil/1.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/marsil/2.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/marsil/3.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/marsil/4.gif">
                	</td>
                </tr>
		<tr>
                	<td>
                	<input type="radio" id="img1" name="visitor_counter_style" value="web">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/web/0.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/web/1.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/web/2.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/web/3.gif">
                	<img src="<?=site_url()?>/wp-content/plugins/visitorcounter/admin/image/web/4.gif">
                	</td>
                </tr>
					            
	</tbody>
        </table>
        <p style="margin-top:20px;">
        <input type="submit" class="button-primary" value="Save Changes" name="submit_style">
        </p>
</form>
</div>

<div style="margin-top:100px;display: none;" id="showShortcode">
    <center><h3>Here Your Shortcode for Visitor Counter</h3>
        <h4>[visitor_counter_count]</h4>
    </center>
</div>

<script>
    $(document).ready(function(){
        $('#showShortcode').hide();
        $('#form_submit').submit(function(){
            $('#showShortcode').show();
        });
    });
</script>


<?php
    global $wpdb;
    $img_style_value = $wpdb->get_results("SELECT img_style FROM visitor_counter_img ", ARRAY_A);
    

    if(empty($img_style_value)){

        if(isset($_POST['submit_style'])){
                $img_style=$_POST['visitor_counter_style'] ;
                
                $data = array(
                    'imgName'=> $img_style,
                    'img_style'=>$img_style
                );
                $wpdb->insert('visitor_counter_img',$data);
        }
    } else{

        if(isset($_POST['submit_style'])){

                $img_style=$_POST['visitor_counter_style'] ; 
                $data = array(
                    'imgName'=> $img_style,
                    'img_style'=>$img_style
                );
                $wpdb->update('visitor_counter_img',$data,array('imgName'=>$img_style_value[0]['img_style']));
        }

    }    




?>