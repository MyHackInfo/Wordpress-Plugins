<?php

/**
 * Fired during plugin deactivation
 *
 * @link       prpwebs.com
 * @since      1.0.0
 *
 * @package    Prpwebs_Blog_Designer
 * @subpackage Prpwebs_Blog_Designer/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Prpwebs_Blog_Designer
 * @subpackage Prpwebs_Blog_Designer/includes
 * @author     narsi <narsi@prpwebs.in>
 */
class Prpwebs_Blog_Designer_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
