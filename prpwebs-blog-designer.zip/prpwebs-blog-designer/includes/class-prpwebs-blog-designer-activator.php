<?php

/**
 * Fired during plugin activation
 *
 * @link       prpwebs.com
 * @since      1.0.0
 *
 * @package    Prpwebs_Blog_Designer
 * @subpackage Prpwebs_Blog_Designer/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Prpwebs_Blog_Designer
 * @subpackage Prpwebs_Blog_Designer/includes
 * @author     narsi <narsi@prpwebs.in>
 */
class Prpwebs_Blog_Designer_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
