<?php 
	echo 'your shortcode : [blog_main_page]';
?>