<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       prpwebs.com
 * @since      1.0.0
 *
 * @package    Prpwebs_Blog_Designer
 * @subpackage Prpwebs_Blog_Designer/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Prpwebs_Blog_Designer
 * @subpackage Prpwebs_Blog_Designer/admin
 * @author     narsi <narsi@prpwebs.in>
 */
class Prpwebs_Blog_Designer_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Prpwebs_Blog_Designer_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Prpwebs_Blog_Designer_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/prpwebs-blog-designer-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Prpwebs_Blog_Designer_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Prpwebs_Blog_Designer_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/prpwebs-blog-designer-admin.js', array( 'jquery' ), $this->version, false );

	}

	public function prpwebs_blog_designer(){
		add_menu_page("PrpWebs Blog Designer","Blog Designer","manage_options","prpwebs-blog-designer","","dashicons-chart-pie",8);
		add_submenu_page("prpwebs-blog-designer","Blog Design Option","Blog Design Option","manage_options","blog-design-option",array($this,"get_blog_tem"));
	}

	public function get_blog_tem(){
		include_once 'partials/blog-design-main-page.php';
	}

	public function blog_main_page_temp($atts, $content=""){
		include_once 'partials/blog-main-page-template.php';
	}


}
