<?php

// =============================================================================
// FUNCTIONS.PHP
// -----------------------------------------------------------------------------
// Overwrite or add your own custom functions to Pro in this file.
// =============================================================================

// =============================================================================
// TABLE OF CONTENTS
// -----------------------------------------------------------------------------
//   01. Enqueue Parent Stylesheet
//   02. Additional Functions
// =============================================================================

// Enqueue Parent Stylesheet
// =============================================================================

add_filter( 'x_enqueue_parent_stylesheet', '__return_true' );

add_filter( 'gform_enable_field_label_visibility_settings', '__return_true' );

function blog_main_shortcode(){
    ob_start();
    get_template_part('blog-page-template');
    return ob_get_clean();
}

add_shortcode('blog_main_shortcode', 'blog_main_shortcode');
