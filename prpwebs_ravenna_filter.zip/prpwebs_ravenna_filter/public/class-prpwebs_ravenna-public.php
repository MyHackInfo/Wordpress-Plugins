<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       prpwebs.com
 * @since      1.0.0
 *
 * @package    Prpwebs_ravenna
 * @subpackage Prpwebs_ravenna/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Prpwebs_ravenna
 * @subpackage Prpwebs_ravenna/public
 * @author     cg pandey <cg@prpwebs.com>
 */
class Prpwebs_ravenna_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Prpwebs_ravenna_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Prpwebs_ravenna_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/prpwebs_ravenna-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Prpwebs_ravenna_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Prpwebs_ravenna_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/prpwebs_ravenna-public.js', array( 'jquery' ), $this->version, false );

    	wp_localize_script( 'ajax_custom_script', 'frontendajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));

	}

	public function myplugin_ajaxurl() {
   		echo '<script type="text/javascript">
           var ajaxurl = "' . admin_url('admin-ajax.php') . '";
         </script>';
	}

	//shortcode method for Produce filters
	public function product_filters_handler($atts, $content = ""){
		include_once 'partials/prpwebs_ravenna-public-display_filters.php';
	}

	//shortcode method for display products
	public function display_products_handler($atts, $content = ""){
		include_once 'partials/prpwebs_ravenna-public-display_products.php';
	}

	//shortcode method for display products
	public function get_term_product_handler($atts, $content = ""){
		$value = $this->get_the_term_link( get_the_ID(), 'post_tag', '', ',' );
		echo $value;
	}

	function get_the_term_link( $id, $taxonomy, $before = '', $sep = '', $after = '' ) {
		$terms = get_the_terms( $id, $taxonomy );

		if ( is_wp_error( $terms ) ) {
			return $terms;
		}

		if ( empty( $terms ) ) {
			return false;
		}

		$links = array();

		foreach ( $terms as $term ) {
			$link = get_term_link( $term, $taxonomy );
			$my_link = $link;
	 		$new_link = str_replace("tag", "partners", $my_link);
			if ( is_wp_error( $new_link ) ) {
				return $new_link;
			}
			$links[] = '<a href="' . esc_url( $new_link ) . '" rel="tag">' . $term->name . '</a>';
		}

		$term_links = apply_filters( "term_links-{$taxonomy}", $links );

		return $before . join( $sep, $term_links ) . $after;
	}


	//shortcode for manufacturer description 
	public function get_term_product_for_manufacturer_handler($atts, $content = ""){
		$value = $this->get_manufacturer_data( get_the_ID(), 'post_tag', '', ',' );
		echo $value;
	}

	/* --------------------- about the manufacturer description --------------------------*/
	function get_manufacturer_data( $id, $taxonomy, $before = '', $sep = '', $after = '' ) {
		$terms = get_the_terms( $id, $taxonomy );
		/*code*/
		$the_slug = $terms[0]->slug;
		$args = array(
		  'name'        => $the_slug,
		  'post_type'   => 'partners',
		  'post_status' => 'publish',
		);
		$my_posts = get_posts($args);
		$meta = get_post_meta($my_posts[0]->ID, 'csf_DataApiManufacturer-Description', true);
	    $csf_recordId = get_post_meta($my_posts[0]->ID, 'csf_recordId', true);
	    //$logoid = get_post_meta($my_posts[0]->ID, 'csf_DataApiManufacturer-Logo', true);
	    //$weburlId = get_post_meta($my_posts[0]->ID, 'csf_DataApiManufacturer-Web URL', true);
	    $views_count = get_post_meta($my_posts[0]->ID, 'trx_addons_post_views_count', true);
	    //$contact = get_post_meta($my_posts[0]->ID, 'csf_DataApiManufacturer-Contact_Details_cl', true);
	    $all = "<div class='desc'>".$meta."</div> <br>";
	    //$all.= "<div class ='rid'> <strong>Record Id : </strong>".$csf_recordId."</div> <br>";
	    //$all.= "<div class ='viewscount'> <strong>Views Count : </strong> ".$views_count."</div> <br>";
	    
		return $all;
	}



	//shortcode for contact Info
	public function get_term_manufacturer_contact_info_handler($atts, $content = ""){
		$value = $this->get_manufacturer_contact_data( get_the_ID(), 'post_tag', '', ',' );
		echo $value;
	}

	/*------------------for contact Info Shortcode-----------------------------*/
	function get_manufacturer_contact_data( $id, $taxonomy, $before = '', $sep = '', $after = '' ) {
		$terms = get_the_terms( $id, $taxonomy );
		/*code*/
		$the_slug = $terms[0]->slug;
		$args = array(
		  'name'        => $the_slug,
		  'post_type'   => 'partners',
		  'post_status' => 'publish',
		);
		$my_posts = get_posts($args);
	    $contact = get_post_meta($my_posts[0]->ID, 'csf_DataApiManufacturer-Contact_Details_cl', true);
	    return $contact;
	}



	//shortcode for Partner logo
	public function get_term_partners_logo_handler($atts, $content = ""){
		$value = $this->get_manufacturer_logo( get_the_ID(), 'post_tag', '', ',' );
		echo $value;
	}


	/*------------------For Partner logo Shortcode-----------------------------*/
	function get_manufacturer_logo( $id, $taxonomy, $before = '', $sep = '', $after = '' ) {
		$terms = get_the_terms( $id, $taxonomy );
		/*code*/
		$the_slug = $terms[0]->slug;
		$args = array(
		  'name'        => $the_slug,
		  'post_type'   => 'partners',
		  'post_status' => 'publish',
		);
		$my_posts = get_posts($args);
	    $contact = get_the_post_thumbnail_url($my_posts[0]->ID);
	    $featured_image = '<img src='.$contact.'>';
	    return $featured_image;
	}


	/*other function*/


	public function prp_product_filters_handler()
	{

		global $wpdb;
		

		$post_filter_data_form = $wpdb->get_results("SELECT * FROM post_filter_table ", ARRAY_A);
		$postType = $post_filter_data_form[0]["postType"];


		$paged = $_POST['pageno'];
		if($_POST['category']=='')
		{
			$cat = -1;
		}
		else{
			$cat = $_POST['category'];
		}
		if($_POST['tag']=='')
		{
			$tag = '';
		}
		else{
			$tag = $_POST['tag'];
		}


		$args =  array( 
		    'post_type' => $postType, 
		    'post_status' => 'publish',
		    'posts_per_page' => 12,
		    'orderby' => 'name', 
		    'order' => 'ASC',
		    'paged' => $paged,
		    'tag_id'=>$tag,
		    'cat'=>$cat
		    /*'tax_query' => array(
		    						'relation' => 'AND', 
		    						 array('taxonomy' => 'rcategory', 'field' => 'term_id', 'terms' => $cat),
		    					)*/
		);
		$posts = new WP_Query($args);
		$totalPage = $posts->found_posts/12;
		if($posts->have_posts())
		$html='';
		else{
			$html='Data Not Found !';
		}
		if ($posts->have_posts()) :
		while ( $posts->have_posts() ) : $posts->the_post();
		$cat =  get_the_category(get_the_ID());
		
		$tag =  get_the_tags( get_the_ID());
		$excerpt = $this->limit_excerpt_word(get_the_excerpt(), '8');
		$link = get_permalink(get_the_ID());
		$title= substr(get_the_title(get_the_ID()), 0, 10);
		$html.= '<div class="vc_col-sm-6 prp_col-6">
			<div class="prp_thumnail">
				<a class="prp_thumbnail_image" href="'.$link.'">'.
					get_the_post_thumbnail(get_the_ID()).'
				</a>
			</div>
			<div class="prp_post">
				<div class="prp_post-meta">
					<span class="post-tags-links">
						<a style="color:#B8BE14; font-weight:700;color:#B8BE14; font-size:26px" href="'.get_site_url().'/partners/'.$tag[0]->slug.'" rel="tag">
							'.$tag[0]->name.'</a>
					</span> <br />
					<span class="categories-links">
						<a href='.get_the_permalink().' style="font-weight:400; display:block; font-size: 26px; text-transform: uppercase;">'.$title.'</a>
						<span style="color:#5F6369; font-weight:400; font-size:18px">'.$cat[0]->name.'</span>
					</span> <br />
					<br>
				</div>
				<br />
				<div class="prp-excerpt">
				    <span style="font-size: 16px;">'.$excerpt.'...'.'     </span>
					<a class="prp-read-more" href="'.$link.'">Read More</a>
			     </div>
			</div>
		</div>';
		endwhile;
		endif;
		
		/*for ajax pagination*/
		if($totalPage>1)
		$loadmore = '<button type="button" onclick="pagination_ajax(this)" class="load_more" data-tag="'.$_POST['tag'].'" data-category="'.$_POST['category'].'" data-pageno='.$_POST['pageno'].' data-btnid="btn'.$_POST['pageno'].'" id="btn'.$_POST['pageno'].'" >Load More</button><div class="prp_spinner_ajax"></div>';
		else
		$loadmore ='';

		echo 
        '<div class="container">' .$html . '</div>' . 
        '<div class="row" style="clear:both;"><div class="col-md-12" style="text-align:center;">' . $loadmore. '</div></div>';
	    exit;
	}

	public function limit_excerpt_word($string, $word_limit) {
		$words = explode(' ', $string);
		return implode(' ', array_slice($words, 0, $word_limit));
	}
 	

 	/*search by product name*/

 	public function prp_pname_filters_handler()
	{

		global $wpdb;
		$paged = $_POST['pageno'];
		$filter_text = $_POST['filter_text'];
		
		$args =  array( 
		    'post_type' => $postType, 
		    'post_status' => 'publish',
		    'posts_per_page' => -1,
		    'orderby' => 'name', 
		    'order' => 'ASC',
		    's' => $filter_text,
		    'paged' => $paged,
		);
		$posts = new WP_Query($args);
		$totalPage = $posts->found_posts/12;
		if($posts->have_posts())
		$html='';
		else{
			$html='Data Not Found !';
		}
		if ($posts->have_posts()) :
		while ( $posts->have_posts() ) : $posts->the_post();
		$cat =  get_the_category(get_the_ID());
		$tag =  get_the_tags( get_the_ID());
		$excerpt = $this->limit_excerpt_word(get_the_excerpt(), '8');
		$link = get_permalink(get_the_ID());
		$title= get_the_title(get_the_ID());
		$html.= '<div class="vc_col-sm-6 prp_col-6">
			<div class="prp_thumnail">
				<a class="prp_thumbnail_image" href="'.$link.'">'.
					get_the_post_thumbnail(get_the_ID()).'
				</a>
			</div>
			<div class="prp_post">
				<div class="prp_post-meta">
					<span class="post-tags-links">
						<a style="color:#B8BE14; font-weight:700;color:#B8BE14; font-size:26px" href="'.get_site_url().'/partners/'.$tag[0]->slug.'" rel="tag">
							'.$tag[0]->name.'</a>
					</span> <br />
					<span class="categories-links">
						<a href='.get_the_permalink().' style="font-weight:400; display:block; font-size: 26px; text-transform: uppercase;">'.$title.'</a>
						<span style="color:#5F6369; font-weight:400; font-size:18px">'.$cat[0]->name.'</span>
					</span> <br />
					<br>
				</div>
				<br />
				<div class="prp-excerpt">
				    <span style="font-size: 16px;">'.$excerpt.'...'.'     </span>
					<a class="prp-read-more" href="'.$link.'">Read More</a>
			     </div>
			</div>
		</div>';
		endwhile;
		endif;
		
		/*for ajax pagination*/
		/*if($totalPage>1)
		$loadmore = '<button type="button" onclick="pagination_ajax(this)" class="load_more" data-tag="'.$_POST['tag'].'" data-category="'.$_POST['category'].'" data-pageno='.$_POST['pageno'].' data-btnid="btn'.$_POST['pageno'].'" id="btn'.$_POST['pageno'].'" >Load More</button><div class="prp_spinner_ajax"></div>';
		else
		$loadmore ='';*/

		echo '<div class="container">' .$html . '</div>' ;
	    exit;
	}








	/*end*/



}
