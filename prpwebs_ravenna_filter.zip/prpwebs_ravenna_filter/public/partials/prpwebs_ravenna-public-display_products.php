<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       prpwebs.com
 * @since      1.0.0
 *
 * @package    Prpwebs_ravenna
 * @subpackage Prpwebs_ravenna/public/partials
 */

global $wpdb;

$post_filter_data_form = $wpdb->get_results("SELECT * FROM post_filter_table ", ARRAY_A);
$postType = $post_filter_data_form[0]["postType"];



$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$args =  array( 
    'post_type' => $postType, 
    'cat' => -1, 
    'post_status' => 'publish',
    'posts_per_page' => 12,
    'orderby' => 'name', 
    'order' => 'ASC',
    'paged' => $paged,
);
$posts = new WP_Query($args);
$pagination = "<div class='page-numbers clear'>" . paginate_links(array(
    'total' => $posts->max_num_pages,
    'current' => $paged,
    'prev_text' => __('<'),
    'next_text' => __('>'),
	)) . "</div>";
 ?>

<div class="container" id="prp_container">
<?php if ($posts->have_posts()) :
	echo "<div class='row'>";
	while ( $posts->have_posts() ) : $posts->the_post();?>

	<div class="vc_col-sm-6 prp_col-6">
		<div class="prp_thumnail">
			<a class="prp_thumbnail_image" href="<?php the_permalink() ?>">
				<?php echo get_the_post_thumbnail(get_the_ID());?>
			</a>
		</div>
		<div class="prp_post">
			<div class="prp_post-meta">
				<span class="post-tags-links"><?php  $tag =  get_the_tags( get_the_ID());?>
					<a href="<?=get_site_url().'/partners/'.$tag[0]->slug?>" rel="tag" style="font-weight:700; font-size: 26px; color:#B8BE14;"> <?php echo $tag[0]->name;?> </a>
				</span><span class="categories-links"><?php $cat =  get_the_category(get_the_ID());?>
					<!-- <a href="<?=get_site_url().'/category/'.$cat[0]->slug?>" rel="tag"><?php echo $cat[0]->name;?>  </a> -->				<a href="<?php the_permalink() ?>" style="font-weight:400; font-size: 26px; text-transform: uppercase;"><?php echo substr( get_the_title(), 0, 10);?></a>
					<span style="color:#5F6369; font-weight:400; font-size:18px"><?php echo $cat[0]->name;?> </span>
				</span>
			</div>
			<br />
			<div class="prp-excerpt">
				<div style="font-size: 16px;" class="excerpt-btn"> <?php 
				echo limit_excerpt_word(get_the_excerpt(), '8').'...';?> </div>
				<span style="margin:2em 0;">
				<a class="prp-read-more" href="<?php the_permalink() ?>">Read More</a></span>
			</div>
		</div>
	</div>

	<?php
	endwhile; 
	echo '</div>'. $pagination;
	endif;?>
</div>
	
<?php 
function limit_excerpt_word($string, $word_limit) {
	$words = explode(' ', $string);
	return implode(' ', array_slice($words, 0, $word_limit));
}


?>

