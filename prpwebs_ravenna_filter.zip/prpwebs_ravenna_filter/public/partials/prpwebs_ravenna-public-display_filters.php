<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       prpwebs.com
 * @since      1.0.0
 *
 * @package    Prpwebs_ravenna
 * @subpackage Prpwebs_ravenna/public/partials
 */

global $wpdb;

$post_filter_data_form = $wpdb->get_results("SELECT * FROM post_filter_table ", ARRAY_A);
$postType = $post_filter_data_form[0]["postType"];
$postCategory = $post_filter_data_form[0]["taxonomyCategory"];
$postTag = $post_filter_data_form[0]["taxonomyTag"];





if($_GET['tag'])
{
	$sel_tag =  $_GET['tag'];
	$urltag = get_term_by('name', strtolower($sel_tag), $postTag);

	?>
	<script type="text/javascript">
    	jQuery(document).ready(function() {
    		auto_products(); 
    	});
	</script>
	<?php
}
else{
	$sel_tag =='';
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<?php 
$tags = get_terms($postTag, array(
        'orderby'    => 'name',
        'order'      => 'ASC',
        'hide_empty' => true,
    ));


$exclude = array(194,119,164,118,115,178,1,117,116,113,112);
$categories = get_categories( array(
    'orderby' => 'name',
    'order'   => 'ASC',
    'hide_empty'    => false, 
    'exclude' => $exclude,
) );


/*$cat_args = array(
    'orderby'       => 'term_id', 
    'order'         => 'ASC',
    'hide_empty'    => false, 
    'post_type'		=> 'rproduct',
    'exclude' 		=> '1',
);

$categories = get_terms('rcategory', $cat_args);*/

$pargs = array(
        'numberposts'      => -1,
        'post_type'        => $postType,
    );

$products = get_posts($pargs);

$cats = array();

?>

<div class="wrap">
	
	<div id="msg"></div>

	<form method="post" id="form_pname_search">
		<div id="prp_menufacturer">
			
			<div class="prp-term-wrap" id="prp-product">
				<label>Product</label>
				<div class="filters">
					<input list="all_products" name="browser" id="pname_search" class="all_products prp_filters" placeholder="Product Name">
					<datalist id="all_products" style="width:150px; overflow: scroll;">
					<?php foreach($products as $product):
							$post_categories = wp_get_post_categories($product->ID); 
							foreach($post_categories as $c){
							    $cat = get_category( $c );
							    $cats[] = $cat->term_id;
							}
						?>
						<option data-value="<?=$product->ID?>"> <?=$product->post_title?> </option>
					<?php endforeach;?>
					</datalist>
				</div>
			</div>
		</div>
		<div class="prp_pname_spinner"></div>
		<button type="button" id="prp_search_pname" class="search_btn" style="margin:0px;">Search</button>
	</form>
	<hr style="margin: 35px 20px;">
	<form method="post">
		<div id="prp_menufacturer">
			
			<?php 
			if(!empty($postTag)){ ?>
			<div class="prp-term-wrap product-tags" id="prp-wrapper">
				<label>Product Tags</label>
				<div class="filters">
					<select class="manufacture prp_filters" id="ptags" name="ptags">
						<option value=" ">All</option>
						<?php foreach($tags as $data):?>
							<option value="<?=$data->term_id?>" <?php echo (strtolower($sel_tag)==strtolower($data->slug))? "selected" : ""?> ><?=$data->name?></option>
						<?php endforeach;?>
					</select>
					<!-- <input type="hidden" name="urltag" id="urltag" value="<?=$urltag->term_id?>"> -->
				</div>
			</div>
			
		<?php }else{} ?>

			<?php 
			if(!empty($postCategory)){ ?>
			<div class="prp-term-wrap product-categories">
				<label>Product Categories</label>
				<div class="prp_category">
					<select class="pcategories prp_filters" id="pcategories" name="pcategories">
						<option value="">All</option>
						<?php 
						 	$categories = array_unique($cats);
							foreach($categories as $cat):
							 $category = get_category( $cat );
								?>
							<option value="<?=$category->term_id?>"><?=$category->name?></option>
						<?php endforeach;?>
					</select>
				</div>
			</div>
			
			<?php }else{} ?>
		</div>
		<div class="prp_spinner"></div>
			<button type="button" id="prp_search_products" class="search_btn">Search</button>

	</form>
</div>

