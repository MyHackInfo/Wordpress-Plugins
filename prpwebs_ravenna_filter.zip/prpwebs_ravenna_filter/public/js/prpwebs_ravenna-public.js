function pagination_ajax(page) {
	jQuery('.prp_spinner_ajax').show();
	var btnid = jQuery(page).attr('data-btnid');
	console.log(btnid);
	jQuery('#'+btnid).hide();
	var data = {
		'action': 'prp_product_filters',
		'url': 'prp_search',
		'tag': jQuery(page).attr('data-tag'),      
		'category': jQuery(page).attr('data-category'),
		'pageno': parseInt(jQuery(page).attr('data-pageno'))+1,
	};
	console.log(data);
	jQuery.post(ajaxurl, data, function(response) {
		jQuery('.prp_spinner_ajax').hide();
		jQuery('#prp_container').append(response);
	});
}

function auto_products($tid) {
		var data = {
			'action': 'prp_product_filters',
			'url': 'prp_search',
			'tag': jQuery('#ptags').val(),
			'category': jQuery('#pcategories').val(),
			'pageno':1,
		};
		jQuery.post(ajaxurl, data, function(response) {
			jQuery('#prp_container').html(response);		
		});
}
jQuery(function() {

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

// for product search from custom post type
	jQuery('#prp_search_products').on('click', function() {
		jQuery('.prp_spinner').show();
		var data = {
			'action': 'prp_product_filters',
			'url': 'prp_search',
			'tag': jQuery('#ptags').val(),
			'category': jQuery('#pcategories').val(),
			'pageno':1,
		};

		jQuery.post(ajaxurl, data, function(response) {
			jQuery('.prp_spinner').hide();
			jQuery('#prp_container').html(response);		
		});

	});

/*set partners button link*/
	jQuery(document).ready(function() {
		var path = window.location.pathname.split( '/' );
		console.log("pathArray[0] is: " + path[1]);
		if(path[1]=='partners')
		{
			//var tag = jQuery('h1.sc_layouts_title_caption').text();
			var tag = path[2];
			var link = '../../products/?tag='+tag;
			jQuery('#products_v_tags a').attr("href", link);
		}
		if(path[1]=='rproduct')
		{
			//var tag = $('#product_tag a').attr('href');
			var path_tag = jQuery('#product_tag a').attr('href');
			if(path_tag!=undefined)
			{
				var split_tag = path_tag.split('/');
				console.log(split_tag);
				var view_tag = '../../products/?tag='+split_tag[4];
				var title = jQuery('#product_tag h2.elementor-heading-title a').text();
				jQuery('.breadcrumbs span a.taxonomy').html("<span property='name'>"+title+"</span>");
				jQuery('.breadcrumbs span a.taxonomy').attr("href", view_tag);
				jQuery('.breadcrumbs span a.taxonomy').attr("title", "Go to "+ title);
				jQuery('#product_tag h2.elementor-heading-title a').attr("href", view_tag);
			}
		}

	});


	// for product search by product name
	jQuery('#prp_search_pname').on('click', function() {
		jQuery('.prp_pname_spinner').show();
		console.log('enter');
		var data = {
			'action': 'prp_pname_filters',
			'url': 'prp_pname_search',
			'filter_text': jQuery('#pname_search').val(),
			'pageno':1,
		};

		jQuery.post(ajaxurl, data, function(response) {
			jQuery('.prp_pname_spinner').hide();
			jQuery('#prp_container').html(response);		
		});

	});



/*end top jquery*/

});


jQuery(document).ready(function(){
 jQuery("a.post.post-rproduct-archive").attr("href", "http://ravenna.copperleaftest.co.uk/products");
 jQuery("a.post.post-rproduct-archive").attr("title", "Go to Products");
	jQuery('a.post.post-rproduct-archive').text("Products"); 

	var path_tag = jQuery('#product_tag a').attr('href');
	if(path_tag!=undefined)
	{
		var split_tag = path_tag.split('/');
		var view_tag = '../../products/?tag='+split_tag[4];
		jQuery('#view_tags a').attr("href", view_tag);
	}
});



