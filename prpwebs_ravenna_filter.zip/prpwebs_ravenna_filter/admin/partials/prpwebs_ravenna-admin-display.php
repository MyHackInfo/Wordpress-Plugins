<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       prpwebs.com
 * @since      1.0.0
 *
 * @package    Prpwebs_ravenna
 * @subpackage Prpwebs_ravenna/admin/partials
 */

global $wpdb;

$post_filter_data_form = $wpdb->get_results("SELECT * FROM post_filter_table ", ARRAY_A);




if(isset($_POST['submit'])){
	$postType = ($_POST['postType']);
	$taxonomyCategory = ($_POST['taxonomyCategory']);
	$taxonomyTag = ($_POST['taxonomyTag']);	



	$post_filter_data = $wpdb->get_results("SELECT * FROM post_filter_table ", ARRAY_A);
	
		if(empty($post_filter_data)){
					
					 $data = array(
	                    'postType'=> $postType,
	                    'taxonomyCategory'=>$taxonomyCategory,
	                    'taxonomyTag'=>$taxonomyTag
	                );
	                $wpdb->insert('post_filter_table',$data);

	                if ($wpdb) {
	                	echo "<h3>Successfully Done</h3>";
	                	echo "<script>window.location.href='admin.php?page=post-filter' </script>";	
	                }
	                
	                
	        }
	    else{

	    		$data = array(
	                    'postType'=> $postType,
	                    'taxonomyCategory'=>$taxonomyCategory,
	                    'taxonomyTag'=>$taxonomyTag
	                );
	            $wpdb->update('post_filter_table',$data,array('id'=>$post_filter_data[0]['id']));
	            
	                
	            if ($wpdb) {
	                	echo "<h3>Successfully Update</h3>";
	                	echo "<script>window.location.href='admin.php?page=post-filter' </script>";	
	                }

	        }	
}

?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<style type="text/css">
	.input-field {
		width: 25%;
	}
	h3{
		color: green;
	}
</style>
<div>

<h2> Post Filter Input Detials</h2>

<form action="" method="post">
	<input type="text" name="postType" placeholder="Enter Post Type" class="input-field" value="<?php echo $post_filter_data_form[0]["postType"]?>"><br><br>
	<input type="text" name="taxonomyCategory" placeholder=" Enter Taxonomy Category" class="input-field" value="<?php echo $post_filter_data_form[0]["taxonomyCategory"]?>"><br><br>
	<input type="text" name="taxonomyTag" placeholder="Enter TaxonomyTag" class="input-field" value="<?php echo $post_filter_data_form[0]["taxonomyTag"]?>"><br><br>

	<button type="submit" class="submit-btn" name="submit">Submit</button>

</form>


</div>

