<?php

/**
 * Fired during plugin activation
 *
 * @link       prpwebs.com
 * @since      1.0.0
 *
 * @package    Prpwebs_ravenna
 * @subpackage Prpwebs_ravenna/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Prpwebs_ravenna
 * @subpackage Prpwebs_ravenna/includes
 * @author     cg pandey <cg@prpwebs.com>
 */
class Prpwebs_ravenna_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

		global $wpdb;
		
		$table_name = 'post_filter_table';
		if ( ! empty( $wpdb->charset ) ) {
		$charset_collate = "DEFAULT CHARACTER SET $wpdb->charset";
		}
		if ( ! empty( $wpdb->collate ) ) {
		$charset_collate .= " COLLATE $wpdb->collate";
		}
		// Add one library admin function for next function
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

		// Data table
		$sql = "CREATE TABLE $table_name (
		  
		  id mediumint(9) NOT NULL AUTO_INCREMENT,
		  postType varchar(100) NOT NULL,
		  taxonomyCategory varchar(100) NOT NULL,
		  taxonomyTag varchar(100) NOT NULL,
		  PRIMARY KEY  (id)
		  
		  ) $charset_collate;";
		dbDelta( $sql );

	}

}
