<?php

/**
 * Fired during plugin deactivation
 *
 * @link       prpwebs.com
 * @since      1.0.0
 *
 * @package    Prpwebs_ravenna
 * @subpackage Prpwebs_ravenna/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Prpwebs_ravenna
 * @subpackage Prpwebs_ravenna/includes
 * @author     cg pandey <cg@prpwebs.com>
 */
class Prpwebs_ravenna_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

		global $wpdb;
		
		// remove table form database
		$sql = "DROP TABLE IF EXISTS post_filter_table";
		$wpdb->query($sql);
		delete_option("my_plugin_db_version");

	}

}
