<?php

/**
 * Fired during plugin activation
 *
 * @link       prpwebs.com
 * @since      1.0.0
 *
 * @package    Ajaxform
 * @subpackage Ajaxform/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Ajaxform
 * @subpackage Ajaxform/includes
 * @author     narsi <narsi@prpwebs.in>
 */
class Ajaxform_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
